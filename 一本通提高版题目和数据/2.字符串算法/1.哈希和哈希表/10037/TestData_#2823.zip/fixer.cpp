#include<cstdio>
#include<cstring>
const int MAXN=100000+5;
const int MAXL=50+5;
const int MAXQ=2000001+5;
char tasks[MAXN][MAXL],tmp[MAXQ];int l;
int main()
{
	freopen("namelist","r",stdin);
	int now=0;
	while(scanf("%s",tasks[++now])==1);
	for(int i=1;i<=now;i++)
	{
		l=strlen(tasks[i]);
		if(tasks[i][l-1]=='t') continue;
		freopen(tasks[i],"r",stdin);
		scanf("%s",tmp);
		if(tmp[0]>='0'&&tmp[0]<='9') scanf("%s",tmp);
		l=strlen(tmp);
		freopen(tasks[i],"w",stdout);
		printf("%d\n%s",l,tmp);
	}
	return 0;
}
